package mx.utez.edu.recuperai2.Model.Calificaciones;

import mx.utez.edu.recuperai2.Model.Alumnos.BeanAlumno;

public class BeanCalificaciones {
    String materia;
    int calificacion;

    BeanAlumno estudiante;

    public BeanCalificaciones(String materia, int calificacion, BeanAlumno estudiante) {
        this.materia = materia;
        this.calificacion = calificacion;
        this.estudiante = estudiante;
    }

    public BeanCalificaciones() {

    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    public BeanAlumno getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(BeanAlumno estudiante) {
        this.estudiante = estudiante;
    }
}

