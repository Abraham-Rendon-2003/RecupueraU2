package mx.utez.edu.recuperai2.Model.Alumnos;

import mx.utez.edu.recuperai2.Utils.MySQLConnection;
import mx.utez.edu.recuperai2.Utils.Response;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoAlumno {
    Connection connection;
    PreparedStatement pstm;
    ResultSet rs;
    MySQLConnection client = new MySQLConnection();

    public List<BeanAlumno> findAll() {
        List<BeanAlumno> estudiantes = new ArrayList<>();
        try{
            connection = client.getConnection();
            pstm = connection.prepareStatement("SELECT * FROM alumnos;");
            rs = pstm.executeQuery();
            while (rs.next()){
                BeanAlumno estudiante = new BeanAlumno();
                estudiante.setId(rs.getInt("id"));
                estudiante.setName(rs.getString("name"));
                estudiante.setSurname(rs.getString("surname"));
                estudiante.setLastname(rs.getString("lastname"));
                estudiante.setBirthday(rs.getString("birthday"));
                estudiante.setCurp(rs.getString("curp"));
                estudiante.setMatricula(rs.getString("matricula"));
                estudiantes.add(estudiante);
            }
        }catch (SQLException e){
            Logger.getLogger(mx.utez.edu.recuperai2.Model.Docentes.DaoDocentes.class.getName()).log(Level.SEVERE,"Error -> findAll"+ e.getMessage());
        }finally {
            client.close(connection,pstm,rs);
        }
        return estudiantes;
    }


    public BeanAlumno findById(int id) {
        BeanAlumno estudiantes = new BeanAlumno();

        try{
            connection = client.getConnection();
            pstm = connection.prepareStatement("SELECT * FROM alumnos WHERE id = ?;");
            pstm.setLong(1,id);
            rs = pstm.executeQuery();
            while(rs.next()) {
                estudiantes.setId(rs.getInt("id"));
                estudiantes.setName(rs.getString("name"));
                estudiantes.setSurname(rs.getString("surname"));
                estudiantes.setLastname(rs.getString("lastname"));
                estudiantes.setBirthday(rs.getString("birthday"));
                estudiantes.setCurp(rs.getString("curp"));
                estudiantes.setMatricula(rs.getString("matricula"));
            }
        }catch (SQLException e){
            Logger.getLogger(mx.utez.edu.recuperai2.Model.Alumnos.DaoAlumno.class.getName()).log(Level.SEVERE,"Error -> findAll"+ e.getMessage());
        }finally{
            client.close(connection,pstm,rs);
        }
        return estudiantes;
    }


    public Response save(BeanAlumno estudiantes) {
        try{
            if (validarCurp(estudiantes.getCurp())){
                return new Response<>(false, "La curp ya existe", null);
            }
            if (validarMatricula(estudiantes.getMatricula())){
                return new Response<>(false, "La matricula ya existe", null);
            }
            connection = client.getConnection();
            pstm = connection.prepareStatement("INSERT INTO alumnos (name,surname,lastname,birthday,curp,matricula) " +
                    "VALUES (?,?,?,?,?,?);");
            pstm.setString(1, estudiantes.getName());
            pstm.setString(2, estudiantes.getSurname());
            pstm.setString(3, estudiantes.getLastname());
            pstm.setString(4, estudiantes.getBirthday());
            pstm.setString(5, estudiantes.getCurp());
            pstm.setString(6,    estudiantes.getMatricula());

            if(pstm.executeUpdate() == 1){
                return new Response<BeanAlumno>(200,"Registro exitoso",estudiantes,false);
            }else{
                return new Response<BeanAlumno>(200,"Error de registro. Intente nuevamente",estudiantes,true);
            }
        }catch (SQLException e){
            Logger.getLogger(mx.utez.edu.recuperai2.Model.Alumnos.DaoAlumno.class.getName()).log(Level.SEVERE,"Error -> findAll"+ e.getMessage());
            return new Response<>(400,"...",null,true);

        }finally {
            client.close(connection,pstm,rs);
        }
    }


    public Response update(BeanAlumno estudiantes) {
        try {
            connection = client.getConnection();
            pstm = connection.prepareStatement("UPDATE alumnos SET name = ?, surname = ?, lastname = ?, birthday = ?, curp = ?, matricula = ? where id = ?;");
            pstm.setString(1, estudiantes.getName());
            pstm.setString(2, estudiantes.getSurname());
            pstm.setString(3, estudiantes.getLastname());
            pstm.setString(4, estudiantes.getBirthday());
            pstm.setString(5, estudiantes.getCurp());
            pstm.setString(6,    estudiantes.getMatricula());
            pstm.setInt(7,    estudiantes.getId());
            if (pstm.executeUpdate() == 1) {
                return new Response<BeanAlumno>(200, "Actualizado exitoso", estudiantes, false);
            } else {
                return new Response<BeanAlumno>(200, "Error de actualizado. Intente nuevamente", estudiantes, true);
            }
        }catch (SQLException e){
            Logger.getLogger(mx.utez.edu.recuperai2.Model.Alumnos.DaoAlumno.class.getName()).log(Level.SEVERE,"Error -> update"+ e.getMessage());
            return new Response<BeanAlumno>(200,"Error con el servidor",estudiantes,true);
        }
    }


    public Response delete(int id) {
        BeanAlumno estudiantes = new BeanAlumno();
        try {
            connection = client.getConnection();
            pstm = connection.prepareStatement("DELETE  FROM alumnos WHERE id = ?;");
            pstm.setInt(1,id);
            if(pstm.executeUpdate() == 1){
                return new Response<BeanAlumno>(200,"Eliminado",estudiantes,false);
            }else{
                return new Response<BeanAlumno>(200,"Error de servidor. Intente nuevamente",estudiantes,true);
            }
        } catch (Exception e) {
            Logger.getLogger(mx.utez.edu.recuperai2.Model.Alumnos.DaoAlumno.class.getName()).log(Level.SEVERE, "Error -> findAll" + e.getMessage());
            return new Response<BeanAlumno>(200, "Error con el servidor", estudiantes, true);
        }finally{
            client.close(connection,pstm,rs);
        }
    }
    public boolean validarCurp(String curp){
        try{
            connection = client.getConnection();
            String query = "SELECT * FROM alumnos WHERE curp = ?;";
            pstm = connection.prepareStatement(query);
            pstm.setString(1, curp);
            rs = pstm.executeQuery();

            if(rs.next()){
                return true;

            }
        }catch (Exception e){
            System.out.println("Error -> validarCurp"+ e.getMessage());

        } finally {
            client.close(connection,pstm,rs);

        }

        return false;
    }

    public boolean validarMatricula(String matricula){

        try{

            connection = client.getConnection();
            String query = "SELECT * FROM alumnos WHERE matricula = ?;";
            pstm = connection.prepareStatement(query);
            pstm.setString(1, matricula);
            rs = pstm.executeQuery();

            if(rs.next()){
                return true;

            }

        }catch (Exception e){
            System.out.println("Error -> validarMatricula"+ e.getMessage());

        } finally {
            client.close(connection,pstm,rs);

        }

        return false;
    }
}