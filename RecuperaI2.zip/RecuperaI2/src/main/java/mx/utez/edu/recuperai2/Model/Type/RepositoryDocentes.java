package mx.utez.edu.recuperai2.Model.Type;

import mx.utez.edu.recuperai2.Model.Docentes.BeanDocentes;
import mx.utez.edu.recuperai2.Utils.Response;

import java.util.List;

public interface RepositoryDocentes <T> {
    List<T> findAll();
    BeanDocentes findById(int id);

    Response save(T object);
    Response update(T object);

    Response delete(int id);

}
