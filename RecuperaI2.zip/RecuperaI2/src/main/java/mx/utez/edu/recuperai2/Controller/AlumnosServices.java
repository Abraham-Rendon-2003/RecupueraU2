package mx.utez.edu.recuperai2.Controller;

import mx.utez.edu.recuperai2.Model.Alumnos.BeanAlumno;
import mx.utez.edu.recuperai2.Model.Alumnos.DaoAlumno;
import mx.utez.edu.recuperai2.Utils.Response;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Path("/api/alumnos")
public class AlumnosServices {
    Map<String,Object> response = new HashMap<>();

    @GET
    @Path("/") @Produces(value = {"application/json"})
    public List<BeanAlumno> getAll(){
        return new DaoAlumno().findAll();
    }

    @POST
    @Path("/") @Consumes(value = {"application/json"}) @Produces(value = {"application/json"})
    public Map<String, Object> save(BeanAlumno estudiantes){
        System.out.println(estudiantes.getName());
        Response<BeanAlumno> result = new DaoAlumno().save(estudiantes);
        response.put("result",result);
        return response;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public BeanAlumno getById(@PathParam("id") int id){
        System.out.println(id);
        return new DaoAlumno().findById(id);
    }
    @PUT
    @Path("/")
    @Consumes(value = {"application/json"})
    @Produces(value = {"application/json"})
    public Map<String, Object> update(BeanAlumno estudiantes){
        System.out.println(estudiantes.getId());
        System.out.println(estudiantes.getName());
        Response<BeanAlumno> result = new DaoAlumno().update(estudiantes);
        response.put("result",result);
        return response;
    }
    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") int id){
        System.out.println(id);
        return new DaoAlumno().delete(id);
    }
}
