package mx.utez.edu.recuperai2.Controller;

import mx.utez.edu.recuperai2.Model.Calificaciones.BeanCalificaciones;
import mx.utez.edu.recuperai2.Model.Docentes.DaoDocentes;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Path("/api/calificaciones")
public class CalificacionesServices {
    Map<String, Object> response = new HashMap<>();

    @GET
    @Path("/")
    @Produces(value = {"application/json"})
    public List<BeanCalificaciones> getAll() {
        return new DaoDocentes().getCalificaciones();
    }
}
