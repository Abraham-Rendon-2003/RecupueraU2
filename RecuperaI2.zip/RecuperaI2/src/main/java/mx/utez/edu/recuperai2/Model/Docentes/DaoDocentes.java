package mx.utez.edu.recuperai2.Model.Docentes;

import mx.utez.edu.recuperai2.Model.Alumnos.BeanAlumno;
import mx.utez.edu.recuperai2.Model.Calificaciones.BeanCalificaciones;
import mx.utez.edu.recuperai2.Utils.MySQLConnection;
import mx.utez.edu.recuperai2.Utils.Response;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoDocentes {
    Connection connection;
    PreparedStatement pstm;
    ResultSet rs;
    MySQLConnection client = new MySQLConnection();

    public List<BeanDocentes> findAll() {
        List<BeanDocentes> docentes = new ArrayList<>();
        try{
            connection = client.getConnection();
            pstm = connection.prepareStatement("SELECT * FROM docentes;");
            rs = pstm.executeQuery();
            while (rs.next()){
                BeanDocentes docente = new BeanDocentes();
                docente.setId(rs.getInt("id"));
                docente.setName(rs.getString("name"));
                docente.setSurname(rs.getString("surname"));
                docente.setLastname(rs.getString("lastname"));
                docente.setBirthday(rs.getString("birthday"));
                docente.setCurp(rs.getString("curp"));
                docente.setId_empleado(rs.getInt("id_empleado"));
                docentes.add(docente);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoDocentes.class.getName()).log(Level.SEVERE,"Error -> findAll"+ e.getMessage());
        }finally {
            client.close(connection,pstm,rs);
        }
        return docentes;
    }


    public BeanDocentes findById(int id) {
        BeanDocentes docente = new BeanDocentes();
        try{
            connection = client.getConnection();
            pstm = connection.prepareStatement("SELECT * FROM docentes WHERE id = ?;");
            pstm.setLong(1,id);
            rs = pstm.executeQuery();
            while(rs.next()) {
                docente.setId(rs.getInt("id"));
                docente.setName(rs.getString("name"));
                docente.setSurname(rs.getString("surname"));
                docente.setLastname(rs.getString("lastname"));
                docente.setBirthday(rs.getString("birthday"));
                docente.setCurp(rs.getString("curp"));
                docente.setId_empleado(rs.getInt("id_empleado"));
            }
        }catch (SQLException e){
            Logger.getLogger(DaoDocentes.class.getName()).log(Level.SEVERE,"Error -> findAll"+ e.getMessage());
        }finally{
            client.close(connection,pstm,rs);
        }
        return docente;
    }


    public Response save(BeanDocentes docente) {
        try{
            if (validarCurp(docente.getCurp())){
                return new Response<>(false, "La curp ya existe", null);
            }
            if (validarNumEmpleado(docente.getId_empleado())){
                return new Response<>(false, "El numero de empleado ya existe", null);
            }
            connection = client.getConnection();
            pstm = connection.prepareStatement("INSERT INTO docentes (name,surname,lastname,birthday,curp,id_empleado) " +
                    "VALUES (?,?,?,?,?,?);");
            pstm.setString(1,  docente.getName());
            pstm.setString(2,  docente.getSurname());
            pstm.setString(3,  docente.getLastname());
            pstm.setString(4,  docente.getBirthday());
            pstm.setString(5,     docente.getCurp());
            pstm.setInt(6,  docente.getId_empleado());

            if(pstm.executeUpdate() == 1){
                return new Response<BeanDocentes>(200,"Registro exitoso",docente,false);
            }else{
                return new Response<BeanDocentes>(200,"Error de registro. Intente nuevamente",docente,true);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoDocentes.class.getName()).log(Level.SEVERE,"Error -> findAll"+e.getMessage());
            return new Response<BeanDocentes>(400,"Ayudaaa",null,true);

        }finally {
            client.close(connection,pstm,rs);
        }
    }


    public Response update(BeanDocentes docente) {
        try {
            connection = client.getConnection();
            pstm = connection.prepareStatement("UPDATE docentes SET name = ?, surname = ?, lastname = ?, birthday = ?, curp = ?, id_empleado = ? where id = ?;");
            pstm.setString(1,  docente.getName());
            pstm.setString(2,  docente.getSurname());
            pstm.setString(3,  docente.getLastname());
            pstm.setString(4,  docente.getBirthday());
            pstm.setString(5,     docente.getCurp());
            pstm.setInt(6,  docente.getId_empleado());
            pstm.setInt(7,   docente.getId());
            if (pstm.executeUpdate() == 1) {
                return new Response<BeanDocentes>(200, "Actualizado exitoso", docente, false);
            } else {
                return new Response<BeanDocentes>(200, "Error de actualizado. Intente nuevamente", docente, true);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoDocentes.class.getName()).log(Level.SEVERE,"Error -> update"+ e.getMessage());
            return new Response<BeanDocentes>(200,"Error con el servidor",docente,true);
        }
    }
    public List<BeanCalificaciones> getCalificaciones() {
        List<BeanCalificaciones> calificaciones = new ArrayList<>();
        BeanCalificaciones calificacion = null;
        BeanAlumno estudiante = null;

        try {
            connection = client.getConnection();
            String query = "SELECT ca.*, es.name FROM calificaciones ca INNER JOIN alumnos es ON ca.curpAlumno = es.curp;";
            pstm = connection.prepareStatement(query);
            rs = pstm.executeQuery();

            while (rs.next()) {
                calificacion = new BeanCalificaciones();
                estudiante = new BeanAlumno();
                estudiante.setName(rs.getString("nombre"));
                calificacion.setEstudiante(estudiante);
                calificacion.setMateria(rs.getString("materia"));
                calificacion.setCalificacion(rs.getInt("calificacion"));
                calificaciones.add(calificacion);
            }

        }catch (SQLException e){
            Logger.getLogger(DaoDocentes.class.getName())
                    .log(Level.SEVERE, "Error -> findAll" + e.getMessage());
        }finally {
            client.close(connection,pstm,rs);
        }
        return calificaciones;
    }

    public Response delete(int id) {
        BeanDocentes docente = new BeanDocentes();
        try {
            connection = client.getConnection();
            pstm = connection.prepareStatement("DELETE  FROM docentes WHERE id = ?;");
            pstm.setInt(1,id);
            if(pstm.executeUpdate() == 1){
                return new Response<BeanDocentes>(200,"Eliminado",docente,false);
            }else{
                return new Response<BeanDocentes>(200,"Error de servidor. Intente nuevamente",docente,true);
            }
        } catch (Exception e) {
            Logger.getLogger(DaoDocentes.class.getName()).log(Level.SEVERE, "Error -> findAll" + e.getMessage());
            return new Response<BeanDocentes>(200, "Error con el servidor", docente, true);
        }finally{
            client.close(connection,pstm,rs);
        }
    }
    public List<BeanCalificaciones> promedio() {
        List<BeanCalificaciones> calificaciones = new ArrayList<>();
        BeanCalificaciones calificacion = null;

        try {
            connection = client.getConnection();
            String query = "SELECT AVG(calificacion) AS promedio FROM calificaciones";
            pstm = connection.prepareStatement(query);
            rs = pstm.executeQuery();

            while (rs.next()) {
                calificacion = new BeanCalificaciones();
                calificacion.setCalificacion(rs.getInt("promedio"));
                calificaciones.add(calificacion);
            }

        }catch (SQLException e){
            Logger.getLogger(DaoDocentes.class.getName()).log(Level.SEVERE, "Error -> findAll" + e.getMessage());
        }finally {
            client.close(connection,pstm,rs);
        }
        return calificaciones;

    }

    public boolean validarCurp(String curp){
        try{
            connection = client.getConnection();
            String query = "SELECT * FROM docentes WHERE curp = ?;";
            pstm = connection.prepareStatement(query);
            pstm.setString(1, curp);
            rs = pstm.executeQuery();

            if(rs.next()){
                return true;

            }
        }catch (Exception e){
            System.out.println("Error -> validarCurp"+ e.getMessage());

        } finally {
            client.close(connection,pstm,rs);

        }

        return false;
    }

    public boolean validarNumEmpleado(int numero){

        try{

            connection = client.getConnection();
            String query = "SELECT * FROM docentes WHERE id_empleado = ?;";
            pstm = connection.prepareStatement(query);
            pstm.setInt(1, numero);
            rs = pstm.executeQuery();

            if(rs.next()){
                return true;

            }

        }catch (Exception e){
            System.out.println("Error -> validarNumEmpleado"+ e.getMessage());

        } finally {
            client.close(connection,pstm,rs);

        }

        return false;
    }
}