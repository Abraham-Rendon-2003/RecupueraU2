package mx.utez.edu.recuperai2.Model.Type;

import mx.utez.edu.recuperai2.Model.Alumnos.BeanAlumno;
import mx.utez.edu.recuperai2.Utils.Response;

import java.util.List;

public interface RepositoryAlumnos <T>{
    List<T> findAll();

    BeanAlumno findById(int id);

    Response save(T object);

    Response update(T object);

    Response delete(int id);
}
