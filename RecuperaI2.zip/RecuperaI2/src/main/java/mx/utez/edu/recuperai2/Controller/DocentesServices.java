package mx.utez.edu.recuperai2.Controller;

import mx.utez.edu.recuperai2.Model.Docentes.BeanDocentes;
import mx.utez.edu.recuperai2.Model.Docentes.DaoDocentes;
import mx.utez.edu.recuperai2.Utils.Response;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Path("/api/docentes")
public class DocentesServices {
    Map<String,Object> response = new HashMap<>();

    @GET
    @Path("/") @Produces(value = {"application/json"})
    public List<BeanDocentes> getAll(){
        return new DaoDocentes().findAll();
    }

    @POST
    @Path("/") @Consumes(value = {"application/json"}) @Produces(value = {"application/json"})
    public Map<String, Object> save(BeanDocentes docente){
        System.out.println(docente.getName());
        Response<BeanDocentes> result = new DaoDocentes().save(docente);
        response.put("result",result);
        return response;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public BeanDocentes getById(@PathParam("id") int id){
        System.out.println(id);
        return new DaoDocentes().findById(id);
    }
    @PUT
    @Path("/")
    @Consumes(value = {"application/json"})
    @Produces(value = {"application/json"})
    public Map<String, Object> update(BeanDocentes docente){
        System.out.println(docente.getId());
        System.out.println(docente.getName());
        Response<BeanDocentes> result = new DaoDocentes().update(docente);
        response.put("result",result);
        return response;
    }
    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") int id){
        System.out.println(id);
        return new DaoDocentes().delete(id);
    }
}
